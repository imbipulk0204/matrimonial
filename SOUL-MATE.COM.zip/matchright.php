<!-- <div class="profile_search1">
	   <form>
		  <input type="text" class="m_1" name="ne" size="30" required="" placeholder="Enter Profile ID :">
		  <input type="submit" value="Go">
	   </form>
  </div> -->
  <section class="slider">
	 <h3>Happy Marriage</h3>
	 <div class="flexslider">
		<ul class="slides">
		  <li>
			<img src="images/s2.jpg" alt=""/>
			<h4>Jhon & Mary</h4>
			<p>It is a long established fact that a reader will be distracted by the readable</p>
		  </li>
		  <!-- <li>
			<img src="images/s1.jpg" alt=""/>
			<h4>Annie & Williams</h4>
			<p>It is a long established fact that a reader will be distracted by the readable</p>
		  </li> -->
		  <!-- <li>
			<img src="images/s3.jpg" alt=""/>
			<h4>Ram & Isha</h4>
			<p>It is a long established fact that a reader will be distracted by the readable</p>
		  </li> -->
	    </ul>
	  </div>
   </section>


</div>
