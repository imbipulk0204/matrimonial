

<?php
$dbservername="localhost";
$dbusername="root";
$dbpassword="";
$dbName="meethub";


$conn=new mysqli($dbservername, $dbusername, $dbpassword, $dbName);


//if ($conn->connect_error) {
//echo ("connection failed:");
//} else {
//    echo("connected successfully");
//}




?>
