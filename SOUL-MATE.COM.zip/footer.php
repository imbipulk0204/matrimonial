


  <!--style="border:px solid blue;margin-left:;margin-right:px;height:10vh;" class="footer">  -->
  <div style="background:#101269;padding-top:40px;margin-top:0px">
    <!--	 align="center" style="padding-left:10px;margin-bottom:"  class="container">  -->
       <div style="background:">
    		<div style="margin-left:260px;" class="col-md-4">
    			<h4 style="color:white">About Us</h4>
				<p style="color:white">BCA department batch(2016-2019) <br> pragjyotish college <br>shantipur Guwahati, Assam <br>  </p>
				<a style="margin-top:150px;color:lightgreen" href="https://goo.gl/maps/gFJWiDkhmqrT1a5a6">find us on map</a>
			</div>
			
    		<div class="col-md-2 col_2">
    			<h4 style="color:white">Help & Support</h4>
    			<ul class="footer_links">
    				<li><a style="color:white" href="#">24x7 Live help</a></li>
    				<li><a style="color:white" href="contact.php">Contact us</a></li>
    				<li><a style="color:white" href="#">Feedback</a></li>
    				<li><a style="color:white" href="faq.php">FAQs</a></li>
    			</ul>
    		</div>
    		<div class="col-md-2 col_2">
    			<h4 style="color:white">Quick Links</h4>
    			<ul class="footer_links">
    				<li><a style="color:white" href="privacy.php">Privacy Policy</a></li>
    				<li><a style="color:white" href="terms.php">Terms and Conditions</a></li>
    				<li><a style="color:white" href="services.php">Services</a></li>
    			</ul>
    		</div>
              
    		<div class="clearfix"> </div>
    		<div style="padding-right:0px" class="copy">
		      <p style="color:white">Copyright © 2019 Marital . All Rights Reserved  | Design by <P style="color:white;font-size:30px;font-weight: 900;" ><B>Bipul kumar <i class="fa fa-minus" aria-hidden="true"></i> Rimi Gupta</B></P>
</a> </p>
<div align="" >

  <ul class="footer_social">
  <li  ><a href="https://www.google.com"><i style="color:;background:red" class="fa fa-facebook fa1"> </i></a></li>
  <li><a href="#"><i style="color:;background:red" class="fa fa-twitter fa1"> </i></a></li>
  <li><a href="#"><i style="color:;background:red" class="fa fa-google-plus fa1"> </i></a></li>
  <li><a href="#"><i style="color:;background:red" class="fa fa-youtube fa1"> </i></a></li>
  </ul>
</div>
	        </div>
    	</div>
</div>
</body>
   <?php   include_once("footer.php"); ?>

</html>
<!-- FlexSlider -->
<script defer src="js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<!--<script>
// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});
</script>  -->
