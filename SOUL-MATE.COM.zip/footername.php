<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
    .fg{
      background-color: #101269;
        color: blue;
        border:1px solid blue;
        margin-top: 75rem;
    }
    </style>
</head>
<body>
<div class="clearfix"> </div>
     <div style="background:#101269;padding-top:40px;margin-top:100px;width:%;height:">
  <!--	 align="center" style="padding-left:10px;margin-bottom:"  class="container">  -->
     <div style="background:">
      <div style="margin-left:100px;" class="col-md-4">
        <h4 style="color:white">About Us</h4>
        <p style="color:white"> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad mini </p>
      </div>
      <div class="col-md-2 col_2">
        <h4 style="color:white">Help & Support</h4>
        <ul class="footer_links">
          <li><a style="color:white" href="#">24x7 Live help</a></li>
          <li><a style="color:white" href="contact.php">Contact us</a></li>
          <li><a style="color:white" href="#">Feedback</a></li>
          <li><a style="color:white" href="faq.php">FAQs</a></li>
        </ul>
      </div>
      <div class="col-md-2 col_2">
        <h4 style="color:white">Quick Links</h4>
        <ul class="footer_links">
          <li><a style="color:white" href="privacy.php">Privacy Policy</a></li>
          <li><a style="color:white" href="terms.php">Terms and Conditions</a></li>
          <li><a style="color:white" href="services.php">Services</a></li>
        </ul>
      </div>

      <div class="clearfix"> </div>
      <div style="padding-right:0px" class="copy">
        <p style="color:white">Copyright © 2019 Marital . All Rights Reserved  | Design by <P style="color:white;font-size:30px" ><B>Bipul kumar</B></P>
</a> </p>
<div align="" >

<ul  class="footer_social">
<li  ><a href="https://www.facebook.com/bipul.prasad.75"><i style="color:;background:red" class="fa fa-facebook fa1"> </i></a></li>
<li><a href="https://twitter.com/im_bipul0204"><i style="color:;background:red" class="fa fa-twitter fa1"> </i></a></li>
<li><a href="https://imbipulkumar96130@gmail.com"><i style="color:;background:red" class="fa fa-google-plus fa1"> </i></a></li>
<!-- <li><a href="#"><i style="color:;background:red" class="fa fa-youtube fa1"> </i></a></li> -->
</ul>
</div>
        </div>
    </div>
</div>
</body>
</html>