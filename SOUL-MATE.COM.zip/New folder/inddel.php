	<!-- <a href="create_profile.php" class="hvr-shutter-out-horizontal">Create your Profile</a>   Millions of verified Members-->

<!--<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script> -->

dropdown
<script>
/*$(document).ready(function(){
    $(".dropdown").hover(
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');
        }
    );
}); */

// if (isset($_SESSION['message'])) {

// echo "<script> alert('" . $_SESSION['message'] . "'); location.reload();</script>";
// unset($_SESSION['message']);
// }
</script>

<!--

<div class="grid_1">
      <div class="container">
      	<h1>Featured Profiles</h1>
       	<div class="heart-divider">
			<span class="grey-line"></span>
			<i class="fa fa-heart pink-heart"></i>
			<i class="fa fa-heart grey-heart"></i>
			<span class="grey-line"></span>
        </div>
        <ul id="flexiselDemo3">
        <?php /*
        	$sql="SELECT * FROM customer";
        	$result=mysqlexec($sql);
        	if($result){
        		while($row=mysqli_fetch_assoc($result)){
        			$name=$row['firstname'] . " " . $row['lastname'];
        			$profileid=$row['cust_id'];
        			$age=$row['age'];
        			$place=$row['state'] . "," . $row['district'];
        			$job=$row['occupation'];

        				//getting profilepic
        				$pic1='';
						$sql2="SELECT * FROM photos WHERE cust_id = $profileid";
						$result2 = mysqlexec($sql2);
						if($result2){
							$row2=mysqli_fetch_array($result2);
							$pic1=$row2['pic1'];
						}
						//got profilepic
						//
					//Printing the html
					echo "<li><div class=\"col_1\"><a href=\"view_profile.php?id={$profileid}\">";
					echo "<img src=\"profile/{$profileid}\/{$pic1}\" alt=\"\" class=\"hover-animation image-zoom-in img-responsive\"/>";
					echo "<div class=\"layer m_1 hidden-link hover-animation delay1 fade-in\">";
					echo "<div class=\"center-middle\">About {$name}</div>";
					echo "</div>";
					echo "<h3><span class=\"m_3\">Profile ID : {$profileid}</span><br>{$age}, {$place}<br>{$job}</h3></a></div>";
					echo "</li>";  */

        		}
        	}

        ?>
          </ul>
	    <script type="text/javascript">
		 $(window).load(function() {
			$("#flexiselDemo3").flexisel({
				visibleItems: 6,
				animationSpeed: 1000,
				autoPlay:false,
				autoPlaySpeed: 3000,
				pauseOnHover: true,
				enableResponsiveBreakpoints: true,
		    	responsiveBreakpoints: {
		    		portrait: {
		    			changePoint:480,
		    			visibleItems: 1
		    		},
		    		landscape: {
		    			changePoint:640,
		    			visibleItems: 2
		    		},
		    		tablet: {
		    			changePoint:768,
		    			visibleItems: 3
		    		}
		    	}
		    });

		});
	   </script>
	   <script type="text/javascript" src="js/jquery.flexisel.js"></script>
    </div>
</div>   -->



suceess_story
<!--
   <li>
    <div class="suceess_story-date">
    <span class="entry-1">Dec 20, 2015</span>
  </div>
  <div class="suceess_story-content-container">
    <figure class="suceess_story-content-featured-image">
       <img width="75" height="75" src="images/13.jpg" class="img-responsive" alt=""/>
      </figure>
    <div class="suceess_story-content-info">
          <h4><a href="#">Lorem & Ipsum</a></h4>
          <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form,.<a href="#">More...</a></p>
        </div>
    </div>
</li>  -->






slide
<!--   <h3>News & Events</h3>
     <div class="box_1">
     <figure class="thumbnail1"><img width="170" height="155" src="images/14.jpg" class="img-responsive" alt=""/></figure>
   <div class="extra-wrap">
   <div class="post-meta">
     <span class="day">
     <time datetime="2014-05-25T10:15:43+00:00">25</time>
     </span>
     <span class="month">
     <time datetime="2014-05-25T10:11:51+00:00">May</time>
     </span>
   </div>
   <h4 class="post-title"><a href="#">There are many variations of passages</a></h4>
   <div class="clearfix"> </div>
   <div class="post-content">The standard chunk of Lorem Ipsum used since the 1500s..</div>
   <a href="#" class="vertical">Read More</a>
   </div>
     </div>
     <div class="box_1">
     <figure class="thumbnail1"><img width="170" height="155" src="images/15.jpg" class="img-responsive" alt=""/></figure>
   <div class="extra-wrap">
   <div class="post-meta">
     <span class="day">
     <time datetime="2014-05-25T10:15:43+00:00">25</time>
     </span>
     <span class="month">
     <time datetime="2014-05-25T10:11:51+00:00">May</time>
     </span>
   </div>
   <h4 class="post-title"><a href="#">There are many variations of passages</a></h4>
   <div class="clearfix"> </div>
   <div class="post-content">The standard chunk of Lorem Ipsum used since the 1500s..</div>
   <a href="#" class="vertical">Read More</a>
   </div>
     </div>
     <div class="box_2">
     <figure class="thumbnail1"><img width="170" height="155" src="images/1.jpg" class="img-responsive" alt=""/></figure>
   <div class="extra-wrap">
   <div class="post-meta">
     <span class="day">
     <time datetime="2014-05-25T10:15:43+00:00">25</time>
     </span>
     <span class="month">
     <time datetime="2014-05-25T10:11:51+00:00">May</time>
     </span>
   </div>
   <h4 class="post-title"><a href="#">There are many variations of passages</a></h4>
   <div class="clearfix"> </div>
   <div class="post-content">The standard chunk of Lorem Ipsum used since the 1500s..</div>
   <a href="#" class="vertical">Read More</a>
   </div>
     </div>
     <div class="religion">
          <div class="religion_1-title">Religion :</div>
    <a href="#" target="_blank" class="religion_1" title="Hindu Matrimonial" style="padding-left:0px !important;">Hindu</a>
     <span>|</span><a href="#" target="_blank" class="religion_1" title="Muslim Matrimonial">Muslim</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Christian Matrimonial">Christian</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Sikh Matrimonial">Sikh</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Inter Religion Matrimonial">Inter Religion</a>
     </div>
     <div class="religion">
          <div class="religion_1-title">Country :</div>
    <a href="#" target="_blank" class="religion_1" title="Hindu Matrimonial" style="padding-left:0px !important;">India</a>
     <span>|</span><a href="#" target="_blank" class="religion_1" title="Muslim Matrimonial">Australia</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Christian Matrimonial">Russia</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Sikh Matrimonial">India</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Inter Religion Matrimonial">Kuwait</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Inter Religion Matrimonial">Uk</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Inter Religion Matrimonial">View All</a>
     </div>
     <div class="religion">
          <div class="religion_1-title">Caste :</div>
    <a href="#" target="_blank" class="religion_1" title="Hindu Matrimonial" style="padding-left:0px !important;">Brahmin</a>
     <span>|</span><a href="#" target="_blank" class="religion_1" title="Muslim Matrimonial">Kapu</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Christian Matrimonial">Kamma</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Sikh Matrimonial">Padmasali</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Inter Religion Matrimonial">Reddy</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Inter Religion Matrimonial">View All</a>
     </div>
     <div class="religion">
          <div class="religion_1-title">Regional :</div>
    <a href="#" target="_blank" class="religion_1" title="Hindu Matrimonial" style="padding-left:0px !important;">Urdu</a>
     <span>|</span><a href="#" target="_blank" class="religion_1" title="Muslim Matrimonial">Hindi</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Christian Matrimonial">Telugu</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Sikh Matrimonial">Marwadi</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Inter Religion Matrimonial">Oriya</a>
   <span>|</span><a href="#" target="_blank" class="religion_1" title="Inter Religion Matrimonial">View All</a>
     </div>
  </div>    -->


  social media

  <!--    <ul class="team-socials">
       <li><a href="#"><span class="icon-social "><i class="fa fa-facebook"></i></span></a></li>
        <li><a href="#"><span class="icon-social "><i class="fa fa-twitter"></i></span></a></li>
        <li><a href="#"><span class="icon-social"><i class="fa fa-google-plus"></i></span></a></li>
      </ul>  -->
      <!--   	   <ul class="team-socials">
                <li><a href="#"><span class="icon-social "><i class="fa fa-facebook"></i></span></a></li>
                <li><a href="#"><span class="icon-social "><i class="fa fa-twitter"></i></span></a></li>
                <li><a href="#"><span class="icon-social"><i class="fa fa-google-plus"></i></span></a></li>
              </ul>  -->
